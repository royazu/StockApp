create view Company_Days as
    select Symbol,COUNT(distinct tDate) total_day
    from Buying
    group by Symbol
go

