create view Pop_Company as
    select CD.Symbol
    from Company_Days CD,Buying
    group by CD.Symbol,CD.total_day
    having total_day>count(distinct Buying.tDate)/2
go

