create view following_days as
SELECT distinct tDate,
    (
        SELECT
            MIN(stockmin.tDate)
        FROM Stock AS stockmin
        WHERE stockmin.tDate > Stock.tDate
            AND Stock.Symbol = stockmin.Symbol
    ) AS NextDate,Symbol
FROM Stock
go

