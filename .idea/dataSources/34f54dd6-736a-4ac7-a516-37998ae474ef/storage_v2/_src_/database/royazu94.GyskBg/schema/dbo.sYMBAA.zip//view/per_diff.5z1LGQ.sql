create view per_diff as
select distinct single_trade.Symbol,100*(curr.Price-prev.Price)/prev.Price as percentage,prev.tDate
from price_diff as curr JOIN price_diff as prev on curr.Symbol=prev.Symbol and curr.Price=prev.next_Price,single_trade
where curr.Symbol=single_trade.Symbol
group by single_trade.Symbol, 100*(curr.Price-prev.Price)/prev.Price,prev.tDate
go

