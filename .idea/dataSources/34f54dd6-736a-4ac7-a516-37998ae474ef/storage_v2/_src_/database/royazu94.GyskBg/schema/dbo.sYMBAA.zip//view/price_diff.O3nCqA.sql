create view price_diff as
select ST.Symbol,S1.Price,(S2.Price) as next_Price,S1.tDate
from Stock S1,Stock S2,following_days,single_trade ST
where S1.Symbol=ST.Symbol AND S2.Symbol=ST.Symbol AND S1.tDate=following_days.tDate AND S2.tDate=following_days.NextDate
group by ST.Symbol, S1.Price, (S2.Price), S1.tDate
go

