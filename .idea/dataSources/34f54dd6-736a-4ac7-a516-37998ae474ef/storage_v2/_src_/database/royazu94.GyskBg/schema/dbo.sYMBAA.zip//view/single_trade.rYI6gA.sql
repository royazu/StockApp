create view single_trade as
select Symbol,tDate
from Buying
except (select B1.Symbol,B1.tDate
        from Buying B1,Buying B2
        where(B1.Symbol=B2.Symbol AND B1.ID!=B2.ID)OR (B1.Symbol=B2.Symbol AND B1.tDate!=B2.tDate))
go

