create view unfiltered_sql_res2 as
select PC.Symbol,I.Name,sum(B.BQuantity) as Quantity
from Pop_Company PC,Investor I,Buying B
where B.Symbol=PC.Symbol AND B.ID=I.ID
group by PC.Symbol, I.Name
having sum(BQuantity)>10
go

