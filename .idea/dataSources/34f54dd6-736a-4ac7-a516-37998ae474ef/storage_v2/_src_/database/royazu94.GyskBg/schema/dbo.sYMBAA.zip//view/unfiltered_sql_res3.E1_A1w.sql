create view unfiltered_sql_res3 as
SELECT ST.tDate,ST.Symbol,I.Name
from single_trade ST,per_diff PD,Investor I,Buying B
where ST.Symbol=PD.Symbol AND percentage >3 AND PD.Symbol=B.Symbol and B.ID=I.ID AND ST.tDate=PD.tDate
group by ST.tDate,ST.Symbol,I.Name
go

