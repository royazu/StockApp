create view DiverseInvestor as
    select distinct Buying.ID
    from Investor,Buying,Company
    where Buying.Symbol=Company.Symbol AND Buying.ID=Investor.ID
    group by Buying.ID,tDate
    having count(distinct Sector) >=8
go

