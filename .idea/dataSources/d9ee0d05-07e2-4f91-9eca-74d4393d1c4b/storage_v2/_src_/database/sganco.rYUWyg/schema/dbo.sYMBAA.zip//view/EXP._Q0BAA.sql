CREATE VIEW EXP AS(
    SELECT NAME, BQuantity*Price AS money
    FROM price)
go

