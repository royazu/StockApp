CREATE VIEW OneDate AS(
    SELECT B.Symbol, B.tDate
    FROM Buying B INNER JOIN oneTime OT on B.Symbol = OT.Symbol)
go

