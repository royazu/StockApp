CREATE VIEW buyCompany AS
    SELECT B.Symbol, B.tDate, B.ID, C.Sector
    FROM Buying B, Company C
    WHERE B.Symbol = C.Symbol
go

