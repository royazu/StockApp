CREATE VIEW currentPrice AS(
    SELECT S.Price, OD.Symbol
    FROM Stock S INNER JOIN OneDate OD ON (S.tDate = OD.tDate AND S.Symbol=OD.Symbol))
go

