create view currentPrices as (
select Symbol, MAX(tDate) dt
from Stock
group by Symbol
)
go

