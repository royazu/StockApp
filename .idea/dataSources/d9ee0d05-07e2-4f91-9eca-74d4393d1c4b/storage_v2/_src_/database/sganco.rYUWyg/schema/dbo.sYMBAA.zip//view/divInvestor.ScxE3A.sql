CREATE VIEW divInvestor AS
    SELECT A.ID, COUNT(DISTINCT A.Sector) AS COUN, A.tDate
    FROM buyCompany A CROSS JOIN buyCompany B
    WHERE A.tDate=B.tDate AND A.ID=B.ID AND A.Sector != B.Sector
    GROUP BY A.ID, A.tDate
go

