create view diverse_sum as
select Name,round(sum(BQuantity*Price),3) as total_sum
from Stock,Buying,Diverse_Investor,Investor
where Investor.ID=diverse_investor.ID AND diverse_investor.ID=Buying.ID AND Buying.Symbol=Stock.Symbol AND Buying.tDate=Stock.tDate
group by Name
go

