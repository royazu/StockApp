create view diversesum as
select Name,round(sum(BQuantity*Price),3) as total_sum
from Stock,Buying,DiverseInvestor,Investor
where Investor.ID=diverseinvestor.ID AND diverseinvestor.ID=Buying.ID AND Buying.Symbol=Stock.Symbol AND Buying.tDate=Stock.tDate
group by Name
go

