CREATE VIEW holders AS
    SELECT A.Symbol, A.ID, SUM(B.BQuantity) AS hold
    FROM Buying B, Buying A, popularCompany P
    WHERE A.ID=B.ID AND A.BQuantity=B.BQuantity AND A.Symbol=B.Symbol AND A.tDate=B.tDate AND A.Symbol=P.Symbol
    GROUP BY A.Symbol, A.ID
    HAVING SUM(B.BQuantity) >= 10
go

