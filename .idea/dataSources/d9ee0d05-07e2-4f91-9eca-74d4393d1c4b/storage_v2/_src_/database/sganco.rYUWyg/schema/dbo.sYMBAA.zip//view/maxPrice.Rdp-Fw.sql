CREATE VIEW maxPrice AS(
    SELECT A.Symbol, MAX(A.hold) AS strong
    FROM holders A, holders B
    WHERE A.ID=B.ID
    GROUP BY A.Symbol
    HAVING MAX(A.hold) > 10)
go

