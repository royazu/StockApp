CREATE VIEW moreThanThree AS(
    SELECT NP.Symbol
    FROM nextPrice NP, currentPrice CP
    WHERE NP.Symbol = CP.Symbol AND (NP.Price/CP.Price) > 1.03
    GROUP BY NP.Symbol)
go

