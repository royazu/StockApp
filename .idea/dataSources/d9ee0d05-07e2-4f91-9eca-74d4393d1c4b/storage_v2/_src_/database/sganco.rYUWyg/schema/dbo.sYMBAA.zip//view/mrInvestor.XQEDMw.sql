CREATE VIEW mrInvestor AS(
    SELECT DISTINCT NAME, Investor.ID AS ID
    FROM divInvestor, Investor
    WHERE divInvestor.ID=Investor.ID AND COUN > 7)
go

