CREATE VIEW nextDate AS(
    SELECT S.Symbol, MIN(S.tDate) AS nextTDate
    FROM Stock S INNER JOIN OneDate OD on S.Symbol = OD.Symbol
    WHERE  S.tDate > OD.tDate
    GROUP BY S.Symbol)
go

