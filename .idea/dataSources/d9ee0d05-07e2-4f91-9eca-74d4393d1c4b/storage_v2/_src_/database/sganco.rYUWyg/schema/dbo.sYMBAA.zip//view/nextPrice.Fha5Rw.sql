CREATE VIEW nextPrice AS(
    SELECT S.Price, ND.Symbol
    FROM Stock S INNER JOIN nextDate ND ON (S.tDate=ND.nextTDate AND S.Symbol=ND.Symbol))
go

