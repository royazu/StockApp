CREATE VIEW oneTime AS(
    SELECT SYMBOL
    FROM Buying
    GROUP BY Symbol
    HAVING COUNT(Symbol) = 1)
go

