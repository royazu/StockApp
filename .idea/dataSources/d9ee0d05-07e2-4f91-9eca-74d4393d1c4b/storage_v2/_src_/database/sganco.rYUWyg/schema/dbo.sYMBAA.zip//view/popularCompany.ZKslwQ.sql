CREATE VIEW popularCompany AS
    SELECT Symbol
    FROM Buying B, numOfDays N
    GROUP BY Symbol
    HAVING COUNT(DISTINCT B.tDate) > 0.5*MAX(N.NUM)
go

