CREATE VIEW price AS(
    SELECT B.BQuantity, B.Symbol, B.tDate, S.Price, M.ID, M.NAME
    FROM Buying B, Stock S, mrInvestor M
    WHERE B.Symbol = S.Symbol AND B.tDate = S.tDate AND B.ID = M.ID)
go

