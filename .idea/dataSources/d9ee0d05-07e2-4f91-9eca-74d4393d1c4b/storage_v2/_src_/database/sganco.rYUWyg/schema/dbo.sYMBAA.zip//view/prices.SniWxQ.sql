create view prices as (
select Stock.tDate, Investor.ID, Stock.Symbol, BQuantity*Price as payed, AvailableCash
from Investor,buying,stock
where Investor.ID = Buying.ID and Buying.Symbol = Stock.Symbol and Buying.tDate = Stock.tDate)
go

