CREATE VIEW strongHolders AS
    SELECT H.Symbol, H.ID, H.hold
    FROM holders H, maxPrice M
    WHERE H.hold=M.strong AND H.Symbol=M.Symbol
go

